import os, csv, sqlite3, hashlib, hmac, secrets
from pathlib import Path
from flask import Flask, request, redirect, url_for, session, render_template_string, flash

ROOT = Path(__file__).resolve().parent
DB_FILE = ROOT / "janmat.db"
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "CHANGE-ME-NOW")
SECRET_KEY = os.environ.get("SECRET_KEY", "CHANGE-THIS-SECRET")
# Keep this key private and stable. Changing it invalidates voter lookups.
EPIC_HASH_KEY = os.environ.get("EPIC_HASH_KEY", "CHANGE-THIS-EPIC-KEY")

app = Flask(__name__)
app.secret_key = SECRET_KEY

CSS = """
<style>
body{font-family:Arial,sans-serif;background:#f2f5f9;color:#172033;margin:0}
.wrap{max-width:720px;margin:22px auto;padding:14px}
.card{background:white;border-radius:16px;padding:22px;margin:14px 0;box-shadow:0 4px 18px #10204012}
h1{color:#16436c;font-size:26px;margin:0 0 10px}
input,button{width:100%;box-sizing:border-box;padding:13px;margin:7px 0;border-radius:9px;font-size:16px}
input{border:1px solid #cbd5e1}button{border:0;background:#155eab;color:white;font-weight:bold}
.note{background:#fff4d6;padding:12px;border-radius:10px;color:#634900}
small,.muted{color:#657184}.choice{border:1px solid #d9e1ea;border-radius:10px;padding:12px;margin:8px 0}
a{color:#155eab}
</style>
"""

def connect():
    c = sqlite3.connect(DB_FILE)
    c.row_factory = sqlite3.Row
    return c

def hash_epic(epic):
    normalized = "".join((epic or "").upper().split())
    return hmac.new(EPIC_HASH_KEY.encode(), normalized.encode(), hashlib.sha256).hexdigest()

def init():
    with connect() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS voters(
            voter_key TEXT PRIMARY KEY, name TEXT NOT NULL,
            part_no TEXT DEFAULT '', serial_no TEXT DEFAULT '')""")
        c.execute("""CREATE TABLE IF NOT EXISTS candidates(
            name TEXT PRIMARY KEY, active INTEGER DEFAULT 1)""")
        c.execute("""CREATE TABLE IF NOT EXISTS votes(
            voter_key TEXT PRIMARY KEY, candidate TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
init()

def import_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        r = csv.DictReader(f)
        if not r.fieldnames or not {"epic","name","part_no","serial_no"}.issubset(set(r.fieldnames)):
            raise ValueError("CSV headers must be: epic,name,part_no,serial_no")
        count = 0
        with connect() as c:
            for row in r:
                epic = (row.get("epic") or "").strip()
                name = (row.get("name") or "").strip()
                part = (row.get("part_no") or "").strip()
                serial = (row.get("serial_no") or "").strip()
                if not epic or not name or not part or not serial:
                    continue
                key = hash_epic(epic)
                c.execute("""INSERT INTO voters(voter_key,name,part_no,serial_no)
                    VALUES(?,?,?,?) ON CONFLICT(voter_key) DO UPDATE SET
                    name=excluded.name,part_no=excluded.part_no,serial_no=excluded.serial_no""",
                    (key,name,part,serial))
                count += 1
        return count

HOME = """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Rodoo Janmat Survey</title>""" + CSS + """</head><body><div class="wrap"><div class="card">
<h1>🗳️ Rodoo Janmat Survey</h1><p class="muted">रोडू गाँव — अनौपचारिक जनमत सर्वेक्षण</p>
<p class="note"><b>जरूरी:</b> यह आधिकारिक चुनाव नहीं है। EPIC/Voter ID नंबर से रिकॉर्ड मिलना, व्यक्ति की पहचान का प्रमाण नहीं है। बिना OTP या अन्य पहचान जाँच के, किसी और का EPIC नंबर जानने वाला व्यक्ति उसके नाम पर वोट डाल सकता है।</p>
<form method="post" action="/lookup"><label>Voter ID / EPIC नंबर</label><input name="epic" required maxlength="30" autocomplete="off" placeholder="अपना EPIC नंबर दर्ज करें"><button>रिकॉर्ड खोजें</button></form>
<p><a href="/results">परिणाम देखें</a> · <a href="/admin">Admin</a></p></div></div></body></html>"""

MATCH = """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>मतदाता रिकॉर्ड</title>""" + CSS + """</head><body><div class="wrap"><div class="card">
<h1>रिकॉर्ड मिला</h1><p>नाम: <b>{{v['name']}}</b></p><p>मतदान भाग: {{v['part_no']}} · क्रमांक: {{v['serial_no']}}</p>
{% if voted %}<p class="note">इस रिकॉर्ड से पहले ही वोट दर्ज है।</p>{% else %}
<p class="note">आगे बढ़ने से पहले पुष्टि करें कि आप इसी रिकॉर्ड के सही मतदाता हैं। इस पेज पर कोई वास्तविक पहचान सत्यापित नहीं हुई है।</p>
<form method="post" action="/vote"><input type="hidden" name="key" value="{{v['voter_key']}}"><button>उम्मीदवार चुनें</button></form>{% endif %}
<a href="/">होम पर लौटें</a></div></div></body></html>"""

VOTE = """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>वोट डालें</title>""" + CSS + """</head><body><div class="wrap"><div class="card">
<h1>उम्मीदवार चुनें</h1><p>मतदाता: <b>{{name}}</b></p>
<form method="post" action="/submit"><input type="hidden" name="key" value="{{key}}">
{% for c in candidates %}<label class="choice"><input style="width:auto" type="radio" name="candidate" value="{{c['name']}}" required> {{c['name']}}</label>{% endfor %}
<button>वोट जमा करें</button></form><a href="/">रद्द करें</a></div></div></body></html>"""

ADMIN = """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin</title>""" + CSS + """</head><body><div class="wrap"><div class="card">
<h1>Admin Panel</h1>{% if not logged %}<form method="post"><label>Admin password</label><input type="password" name="password" required><button>Login</button></form>
{% else %}<h3>उम्मीदवार जोड़ें</h3><form method="post" action="/admin/candidate"><input name="candidate" placeholder="उम्मीदवार का नाम" required><button>उम्मीदवार जोड़ें</button></form>
<h3>Voter CSV आयात करें</h3><p class="muted">CSV headers: epic,name,part_no,serial_no. EPIC नंबर import के बाद hash के रूप में रखा जाता है; raw EPIC नंबर डेटाबेस में सेव नहीं होता। CSV को निजी रखें और अपलोड के बाद सुरक्षित रूप से हटाएँ।</p>
<form method="post" action="/admin/import" enctype="multipart/form-data"><input type="file" name="csvfile" accept=".csv" required><button>CSV आयात करें</button></form>
<h3>उम्मीदवार</h3><ul>{% for c in candidates %}<li>{{c['name']}}</li>{% endfor %}</ul>
<a href="/admin/logout">Logout</a> · <a href="/results">Results</a>{% endif %}
<p><a href="/">होम</a></p></div></div></body></html>"""

@app.route("/")
def home(): return render_template_string(HOME)

@app.route("/lookup", methods=["POST"])
def lookup():
    epic = (request.form.get("epic") or "").strip()
    if not epic: return redirect(url_for("home"))
    key = hash_epic(epic)
    with connect() as c:
        v = c.execute("SELECT * FROM voters WHERE voter_key=?", (key,)).fetchone()
        if not v:
            return render_template_string("""<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">""" + CSS + """<div class="wrap"><div class="card"><h1>रिकॉर्ड नहीं मिला</h1><p>EPIC नंबर जाँचें।</p><a href="/">फिर से कोशिश करें</a></div></div>""")
        voted = c.execute("SELECT 1 FROM votes WHERE voter_key=?", (key,)).fetchone() is not None
    return render_template_string(MATCH, v=v, voted=voted)

@app.route("/vote", methods=["POST"])
def vote():
    if not request.form.get("key"): return redirect(url_for("home"))
    with connect() as c:
        v = c.execute("SELECT * FROM voters WHERE voter_key=?", (request.form["key"],)).fetchone()
        if not v: return redirect(url_for("home"))
        if c.execute("SELECT 1 FROM votes WHERE voter_key=?", (v["voter_key"],)).fetchone(): return redirect(url_for("home"))
        candidates = c.execute("SELECT name FROM candidates WHERE active=1 ORDER BY name").fetchall()
    if not candidates:
        return "Admin has not added candidates yet.", 400
    return render_template_string(VOTE, key=v["voter_key"], name=v["name"], candidates=candidates)

@app.route("/submit", methods=["POST"])
def submit():
    key = request.form.get("key","")
    candidate = request.form.get("candidate","")
    with connect() as c:
        v = c.execute("SELECT name FROM voters WHERE voter_key=?", (key,)).fetchone()
        valid = c.execute("SELECT 1 FROM candidates WHERE name=? AND active=1", (candidate,)).fetchone()
        if not v or not valid: return redirect(url_for("home"))
        try: c.execute("INSERT INTO votes(voter_key,candidate) VALUES(?,?)", (key,candidate))
        except sqlite3.IntegrityError:
            return "इस रिकॉर्ड से वोट पहले ही दर्ज है। <a href='/'>होम</a>"
    return """<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">""" + CSS + """<div class="wrap"><div class="card"><h1>वोट दर्ज हुआ</h1><p>इस मतदाता रिकॉर्ड से एक वोट दर्ज किया गया।</p><a href="/">होम</a></div></div>"""

@app.route("/results")
def results():
    with connect() as c:
        rows = c.execute("""SELECT candidates.name,COUNT(votes.voter_key) AS n FROM candidates
        LEFT JOIN votes ON votes.candidate=candidates.name WHERE candidates.active=1
        GROUP BY candidates.name ORDER BY candidates.name""").fetchall()
        total = c.execute("SELECT COUNT(*) FROM votes").fetchone()[0]
    return render_template_string("""<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">""" + CSS + """<div class="wrap"><div class="card"><h1>परिणाम</h1><p>कुल दर्ज वोट: <b>{{total}}</b></p>{% for r in rows %}<div class="choice"><b>{{r['name']}}</b>: {{r['n']}} वोट</div>{% endfor %}<p class="muted">अनौपचारिक सर्वेक्षण के परिणाम।</p><a href="/">होम</a></div></div>""", rows=rows,total=total)

@app.route("/admin", methods=["GET","POST"])
def admin():
    if request.method=="POST" and request.form.get("password")==ADMIN_PASSWORD:
        session["admin"]=True
        return redirect(url_for("admin"))
    with connect() as c: candidates=c.execute("SELECT name FROM candidates WHERE active=1 ORDER BY name").fetchall()
    return render_template_string(ADMIN, logged=session.get("admin",False), candidates=candidates)

@app.route("/admin/candidate", methods=["POST"])
def add_candidate():
    if not session.get("admin"): return redirect(url_for("admin"))
    name=(request.form.get("candidate") or "").strip()
    if name:
        with connect() as c: c.execute("INSERT OR IGNORE INTO candidates(name) VALUES(?)",(name,))
    return redirect(url_for("admin"))

@app.route("/admin/import", methods=["POST"])
def import_voters():
    if not session.get("admin"): return redirect(url_for("admin"))
    f=request.files.get("csvfile")
    if not f or not f.filename.lower().endswith(".csv"): return "CSV file required",400
    tmp=ROOT/"temporary_upload.csv"
    f.save(tmp)
    try: count=import_csv(tmp)
    except Exception as e: return f"CSV import error: {e}",400
    finally:
        try: tmp.unlink()
        except: pass
    return f"आयात सफल: {count} रिकॉर्ड। <a href='/admin'>Admin पर लौटें</a>"

@app.route("/admin/logout")
def logout():
    session.pop("admin",None)
    return redirect(url_for("admin"))

if __name__ == "__main__":
    app.run(host="127.0.0.1",port=5000,debug=False)