RODOO VOTER-ID JANMAT SURVEY — STARTER
======================================
Unofficial opinion poll only; not an official election system.

Flow: enter EPIC/Voter ID -> look up record -> choose candidate -> one vote per stored voter record.
No OTP is used, as requested.

IMPORTANT SECURITY LIMITATION:
EPIC lookup is NOT identity verification. Anyone who knows another person's EPIC number may impersonate them and cast the first vote for that record. This starter cannot guarantee that only the actual cardholder votes. Do not use it for an official or legally consequential election.

Privacy:
- EPIC values are HMAC-hashed during CSV import; raw EPIC is not stored in the SQLite database.
- The HMAC key must remain private and stable.
- Publicly hosting voter data can create privacy risks. Import only the necessary records, restrict admin access, use HTTPS, and do not publish the original PDFs.
- This is a prototype, not production-hardened. Before public deployment, use strong secrets, secure hosting, rate limiting, backups, audit/security review, and a privacy notice.

Setup:
1. Install Python 3.10+
2. pip install -r requirements.txt
3. Set environment variables:
   ADMIN_PASSWORD = strong unique password
   SECRET_KEY = long random secret
   EPIC_HASH_KEY = long random private key
4. python app.py
5. Open http://127.0.0.1:5000
6. Admin -> add candidate names -> import CSV

CSV headers required:
epic,name,part_no,serial_no

Template file is included. The uploaded PDFs are image-heavy and OCR can be inaccurate, so the real EPIC/name/part/serial data still needs careful extraction and checking before import.